import 'package:flutter/material.dart';

import '../services/db.dart';

/// زر إبلاغ عن محتوى مسيء أو وظيفة وهمية (مطلوب لمحتوى المستخدمين في جوجل بلاي)
class ReportButton extends StatelessWidget {
  final String type; // 'job' | 'resume'
  final String targetId;
  const ReportButton({super.key, required this.type, required this.targetId});

  static const reasons = [
    'محتوى مسيء',
    'وظيفة وهمية أو احتيال',
    'تطلب دفع رسوم',
    'بيانات مضللة',
    'أخرى',
  ];

  @override
  Widget build(BuildContext context) {
    return IconButton(
      tooltip: 'إبلاغ',
      icon: const Icon(Icons.flag_outlined),
      onPressed: () async {
        final reason = await showDialog<String>(
          context: context,
          builder: (_) => SimpleDialog(
            title: const Text('سبب الإبلاغ'),
            children: [
              for (final r in reasons)
                SimpleDialogOption(
                    onPressed: () => Navigator.pop(context, r), child: Text(r)),
            ],
          ),
        );
        if (reason == null) return;
        await Db.report(type: type, targetId: targetId, reason: reason);
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('تم إرسال البلاغ، سنراجعه')));
        }
      },
    );
  }
}
