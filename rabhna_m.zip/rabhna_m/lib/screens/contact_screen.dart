import 'package:flutter/material.dart';

import '../services/db.dart';

class ContactScreen extends StatefulWidget {
  const ContactScreen({super.key});
  @override
  State<ContactScreen> createState() => _ContactScreenState();
}

class _ContactScreenState extends State<ContactScreen> {
  final _text = TextEditingController();
  bool _busy = false;

  Future<void> _send() async {
    if (_text.text.trim().isEmpty) return;
    setState(() => _busy = true);
    await Db.sendMessage(_text.text.trim());
    if (!mounted) return;
    _text.clear();
    setState(() => _busy = false);
    ScaffoldMessenger.of(context)
        .showSnackBar(const SnackBar(content: Text('تم إرسال رسالتك')));
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('تواصل معنا')),
        body: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              TextField(
                controller: _text,
                maxLines: 6,
                decoration: const InputDecoration(
                    labelText: 'اكتب رسالتك', border: OutlineInputBorder()),
              ),
              const SizedBox(height: 16),
              FilledButton(
                  onPressed: _busy ? null : _send, child: const Text('إرسال')),
            ],
          ),
        ),
      ),
    );
  }
}
