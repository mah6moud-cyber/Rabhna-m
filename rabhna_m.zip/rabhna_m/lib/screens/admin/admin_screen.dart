import 'package:flutter/material.dart';

import '../../config.dart';
import '../../services/db.dart';

/// لوحة التحكم (للمشرف فقط): المستخدمين ونصيبهم، طلبات السحب، الرسائل، والمنصات.
class AdminScreen extends StatelessWidget {
  const AdminScreen({super.key});

  @override
  Widget build(BuildContext context) {
    if (!Db.isAdmin) {
      return const Scaffold(body: Center(child: Text('غير مصرّح')));
    }
    return Directionality(
      textDirection: TextDirection.rtl,
      child: DefaultTabController(
        length: 5,
        child: Scaffold(
          appBar: AppBar(
            title: const Text('لوحة التحكم'),
            bottom: const TabBar(isScrollable: true, tabs: [
              Tab(text: 'المستخدمين'),
              Tab(text: 'السحب'),
              Tab(text: 'الرسائل'),
              Tab(text: 'المنصات'),
              Tab(text: 'البلاغات'),
            ]),
          ),
          body: const TabBarView(children: [
            _UsersTab(),
            _WithdrawalsTab(),
            _MessagesTab(),
            _PlatformsTab(),
            _ReportsTab(),
          ]),
        ),
      ),
    );
  }
}

/// نقاط المستخدمين + نصيبهم. نصيب المستخدم = نقاطه × الإيراد الحقيقي لكل نقطة × 30%
class _UsersTab extends StatelessWidget {
  const _UsersTab();

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
      stream: Db.config(),
      builder: (context, cfgSnap) {
        final rpp = ((cfgSnap.data?.data()?['revenuePerPoint'] ?? 0) as num).toDouble();
        return Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                        'الإيراد الحقيقي لكل نقطة: ${rpp.toStringAsFixed(4)} ج\n'
                        'المستخدم ${(kUserShare * 100).round()}% | أنت ${(kOwnerShare * 100).round()}%'),
                  ),
                  OutlinedButton(
                    onPressed: () => _editRate(context, rpp),
                    child: const Text('تعديل'),
                  ),
                ],
              ),
            ),
            Expanded(
              child: StreamBuilder(
                stream: Db.adminUsers(),
                builder: (context, snap) {
                  if (!snap.hasData) {
                    return const Center(child: CircularProgressIndicator());
                  }
                  return ListView(
                    children: [
                      for (final d in snap.data!.docs)
                        Builder(builder: (_) {
                          final pts = (d.data()['points'] ?? 0) as int;
                          final revenue = pts * rpp;
                          return ListTile(
                            title: Text(d.data()['email'] ?? d.id),
                            subtitle: Text(
                                'الإيراد: ${revenue.toStringAsFixed(2)} ج  |  '
                                'نصيبه: ${(revenue * kUserShare).toStringAsFixed(2)} ج  |  '
                                'نصيبك: ${(revenue * kOwnerShare).toStringAsFixed(2)} ج'),
                            trailing: Text('$pts نقطة'),
                          );
                        }),
                    ],
                  );
                },
              ),
            ),
          ],
        );
      },
    );
  }

  Future<void> _editRate(BuildContext context, double current) async {
    final c = TextEditingController(text: current.toString());
    final v = await showDialog<double>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('الإيراد الحقيقي لكل نقطة (بالجنيه)'),
        content: TextField(
            controller: c, keyboardType: const TextInputType.numberWithOptions(decimal: true)),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, double.tryParse(c.text)),
              child: const Text('حفظ')),
        ],
      ),
    );
    if (v != null) await Db.setRevenuePerPoint(v);
  }
}

class _WithdrawalsTab extends StatelessWidget {
  const _WithdrawalsTab();

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
      stream: Db.adminWithdrawals(),
      builder: (context, snap) {
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        return ListView(
          children: [
            for (final d in snap.data!.docs)
              Card(
                margin: const EdgeInsets.all(8),
                child: ListTile(
                  title: Text('${d['points']} نقطة - ${d['method']}'),
                  subtitle: Text('${d['email']}\nالمحفظة: ${d['phone']}\nالحالة: ${d['status']}'),
                  isThreeLine: true,
                  trailing: d['status'] == 'pending'
                      ? Row(mainAxisSize: MainAxisSize.min, children: [
                          IconButton(
                              tooltip: 'تم التحويل',
                              icon: const Icon(Icons.check_circle, color: Colors.green),
                              onPressed: () => Db.setWithdrawStatus(d.id, 'paid')),
                          IconButton(
                              tooltip: 'رفض',
                              icon: const Icon(Icons.cancel, color: Colors.red),
                              onPressed: () => Db.setWithdrawStatus(d.id, 'rejected')),
                        ])
                      : null,
                ),
              ),
          ],
        );
      },
    );
  }
}

class _MessagesTab extends StatelessWidget {
  const _MessagesTab();

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
      stream: Db.adminMessages(),
      builder: (context, snap) {
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        return ListView(
          children: [
            for (final d in snap.data!.docs)
              ListTile(title: Text(d['text']), subtitle: Text(d['email'] ?? '')),
          ],
        );
      },
    );
  }
}

class _PlatformsTab extends StatelessWidget {
  const _PlatformsTab();

  Future<void> _add(BuildContext context, String type) async {
    final name = TextEditingController();
    final url = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(type == 'ads' ? 'إضافة منصة إعلانات' : 'إضافة منصة ألعاب'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: name, decoration: const InputDecoration(labelText: 'الاسم')),
          TextField(controller: url, decoration: const InputDecoration(labelText: 'الرابط (https://...)')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('إضافة')),
        ],
      ),
    );
    if (ok == true && name.text.isNotEmpty && url.text.startsWith('https://')) {
      await Db.addPlatform(type, name.text.trim(), url.text.trim());
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        FilledButton.icon(
            onPressed: () => _add(context, 'ads'),
            icon: const Icon(Icons.add),
            label: const Text('إضافة منصة إعلانات')),
        const SizedBox(height: 8),
        FilledButton.icon(
            onPressed: () => _add(context, 'games'),
            icon: const Icon(Icons.add),
            label: const Text('إضافة منصة ألعاب')),
      ],
    );
  }
}

class _ReportsTab extends StatelessWidget {
  const _ReportsTab();

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
      stream: Db.adminReports(),
      builder: (context, snap) {
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        final docs = snap.data!.docs;
        if (docs.isEmpty) return const Center(child: Text('لا توجد بلاغات'));
        return ListView(
          children: [
            for (final d in docs)
              Card(
                margin: const EdgeInsets.all(8),
                child: ListTile(
                  title: Text('${d['type'] == 'job' ? 'وظيفة' : 'سيرة ذاتية'}: ${d['reason']}'),
                  subtitle: Text('المعرّف: ${d['targetId']}\nالحالة: ${d['status']}'),
                  isThreeLine: true,
                  trailing: d['status'] == 'open'
                      ? Row(mainAxisSize: MainAxisSize.min, children: [
                          IconButton(
                              tooltip: 'حذف المحتوى المبلّغ عنه',
                              icon: const Icon(Icons.delete, color: Colors.red),
                              onPressed: () => Db.resolveReport(d.id,
                                  deleteType: d['type'], deleteId: d['targetId'])),
                          IconButton(
                              tooltip: 'تجاهل',
                              icon: const Icon(Icons.check),
                              onPressed: () => Db.resolveReport(d.id)),
                        ])
                      : null,
                ),
              ),
          ],
        );
      },
    );
  }
}
