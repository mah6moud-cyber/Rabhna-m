import 'package:flutter/material.dart';

import '../../services/db.dart';
import '../../widgets/report.dart';

/// زر "ابحث عن عمل": يعرض الوظائف المنشورة (من "ابحث عن عامل")
/// وفيه زر إضافة السيرة الذاتية. السيرة تُحفظ في صفحة المستخدم وتُنشر في "ابحث عن عامل".
class FindJobScreen extends StatelessWidget {
  const FindJobScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('ابحث عن عمل')),
        floatingActionButton: FloatingActionButton.extended(
          icon: const Icon(Icons.description),
          label: const Text('إضافة السيرة الذاتية'),
          onPressed: () => Navigator.push(context,
              MaterialPageRoute(builder: (_) => const ResumeFormScreen())),
        ),
        body: StreamBuilder(
          stream: Db.allJobs(),
          builder: (context, snap) {
            if (!snap.hasData) {
              return const Center(child: CircularProgressIndicator());
            }
            final docs = snap.data!.docs;
            if (docs.isEmpty) {
              return const Center(child: Text('لا توجد وظائف منشورة حالياً'));
            }
            return ListView.builder(
              padding: const EdgeInsets.only(bottom: 90),
              itemCount: docs.length,
              itemBuilder: (_, i) {
                final d = docs[i].data();
                return Card(
                  margin: const EdgeInsets.all(8),
                  child: ListTile(
                    title: Text(d['title'] ?? ''),
                    subtitle: Text(
                        '${d['city'] ?? ''}  •  ${d['salary'] ?? ''}\n${d['description'] ?? ''}\nللتواصل: ${d['phone'] ?? ''}'),
                    isThreeLine: true,
                    trailing: ReportButton(type: 'job', targetId: docs[i].id),
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}

class ResumeFormScreen extends StatefulWidget {
  const ResumeFormScreen({super.key});
  @override
  State<ResumeFormScreen> createState() => _ResumeFormScreenState();
}

class _ResumeFormScreenState extends State<ResumeFormScreen> {
  final _form = GlobalKey<FormState>();
  final _c = {
    for (final k in ['name', 'job', 'city', 'phone', 'experience', 'about'])
      k: TextEditingController()
  };
  bool _loaded = false;

  Widget _field(String key, String label, {int lines = 1, bool required = true}) =>
      Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: TextFormField(
          controller: _c[key],
          maxLines: lines,
          decoration:
              InputDecoration(labelText: label, border: const OutlineInputBorder()),
          validator: (v) =>
              required && (v == null || v.trim().isEmpty) ? 'مطلوب' : null,
        ),
      );

  Future<void> _save() async {
    if (!_form.currentState!.validate()) return;
    await Db.saveResume({for (final e in _c.entries) e.key: e.value.text.trim()});
    if (mounted) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('تم حفظ السيرة الذاتية ونشرها')));
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('سيرتي الذاتية')),
        body: StreamBuilder(
          stream: Db.myResume(),
          builder: (context, snap) {
            if (snap.hasData && !_loaded && snap.data!.exists) {
              final d = snap.data!.data()!;
              for (final e in _c.entries) {
                e.value.text = (d[e.key] ?? '').toString();
              }
              _loaded = true;
            }
            return Form(
              key: _form,
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  _field('name', 'الاسم'),
                  _field('job', 'المهنة / الوظيفة المطلوبة'),
                  _field('city', 'المدينة'),
                  _field('phone', 'رقم التواصل'),
                  _field('experience', 'الخبرات', lines: 3),
                  _field('about', 'نبذة عنك', lines: 3, required: false),
                  FilledButton(onPressed: _save, child: const Text('حفظ ونشر')),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}
