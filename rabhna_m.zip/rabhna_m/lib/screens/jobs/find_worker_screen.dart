import 'package:flutter/material.dart';

import '../../services/db.dart';
import '../../widgets/report.dart';

/// زر "ابحث عن عامل": يعرض السير الذاتية المنشورة (من "ابحث عن عمل")
/// وفيه زر إضافة تفاصيل العمل. التفاصيل تُحفظ في صفحة المستخدم وتُنشر في "ابحث عن عمل".
class FindWorkerScreen extends StatelessWidget {
  const FindWorkerScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('ابحث عن عامل')),
        floatingActionButton: FloatingActionButton.extended(
          icon: const Icon(Icons.add_business),
          label: const Text('إضافة تفاصيل العمل'),
          onPressed: () => Navigator.push(context,
              MaterialPageRoute(builder: (_) => const JobFormScreen())),
        ),
        body: StreamBuilder(
          stream: Db.allResumes(),
          builder: (context, snap) {
            if (!snap.hasData) {
              return const Center(child: CircularProgressIndicator());
            }
            final docs = snap.data!.docs;
            if (docs.isEmpty) {
              return const Center(child: Text('لا توجد سير ذاتية منشورة حالياً'));
            }
            return ListView.builder(
              padding: const EdgeInsets.only(bottom: 90),
              itemCount: docs.length,
              itemBuilder: (_, i) {
                final d = docs[i].data();
                return Card(
                  margin: const EdgeInsets.all(8),
                  child: ListTile(
                    title: Text('${d['name'] ?? ''} - ${d['job'] ?? ''}'),
                    subtitle: Text(
                        '${d['city'] ?? ''}\nالخبرات: ${d['experience'] ?? ''}\nللتواصل: ${d['phone'] ?? ''}'),
                    isThreeLine: true,
                    trailing: ReportButton(type: 'resume', targetId: docs[i].id),
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}

class JobFormScreen extends StatefulWidget {
  const JobFormScreen({super.key});
  @override
  State<JobFormScreen> createState() => _JobFormScreenState();
}

class _JobFormScreenState extends State<JobFormScreen> {
  final _form = GlobalKey<FormState>();
  final _c = {
    for (final k in ['title', 'city', 'salary', 'phone', 'description'])
      k: TextEditingController()
  };

  Widget _field(String key, String label, {int lines = 1}) => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: TextFormField(
          controller: _c[key],
          maxLines: lines,
          decoration:
              InputDecoration(labelText: label, border: const OutlineInputBorder()),
          validator: (v) => (v == null || v.trim().isEmpty) ? 'مطلوب' : null,
        ),
      );

  Future<void> _save() async {
    if (!_form.currentState!.validate()) return;
    await Db.addJob({for (final e in _c.entries) e.key: e.value.text.trim()});
    if (mounted) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('تم حفظ العمل ونشره')));
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('تفاصيل العمل')),
        body: Form(
          key: _form,
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              _field('title', 'عنوان الوظيفة'),
              _field('city', 'المدينة'),
              _field('salary', 'الأجر'),
              _field('phone', 'رقم التواصل'),
              _field('description', 'التفاصيل', lines: 4),
              FilledButton(onPressed: _save, child: const Text('حفظ ونشر')),
              const SizedBox(height: 24),
              const Text('إعلاناتي',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              StreamBuilder(
                stream: Db.myJobs(),
                builder: (context, snap) {
                  if (!snap.hasData) return const SizedBox();
                  return Column(
                    children: [
                      for (final doc in snap.data!.docs)
                        ListTile(
                          title: Text(doc.data()['title'] ?? ''),
                          trailing: IconButton(
                            icon: const Icon(Icons.delete_outline),
                            onPressed: () => Db.deleteJob(doc.id),
                          ),
                        ),
                    ],
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
