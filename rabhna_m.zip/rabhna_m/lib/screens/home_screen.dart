import 'package:flutter/material.dart';

import '../services/db.dart';
import 'admin/admin_screen.dart';
import 'contact_screen.dart';
import 'earn/earn_screen.dart';
import 'settings_screen.dart';
import 'jobs/find_job_screen.dart';
import 'jobs/find_worker_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    Widget tile(IconData icon, String title, Widget page) => Card(
          child: InkWell(
            onTap: () => Navigator.push(
                context, MaterialPageRoute(builder: (_) => page)),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(icon, size: 48),
                const SizedBox(height: 8),
                Text(title,
                    style: const TextStyle(
                        fontSize: 18, fontWeight: FontWeight.w600)),
              ],
            ),
          ),
        );

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('ربحنا-M'),
          actions: [
            if (Db.isAdmin)
              IconButton(
                tooltip: 'لوحة التحكم',
                icon: const Icon(Icons.admin_panel_settings),
                onPressed: () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const AdminScreen())),
              ),
            IconButton(
              tooltip: 'الإعدادات',
              icon: const Icon(Icons.settings),
              onPressed: () => Navigator.push(context,
                  MaterialPageRoute(builder: (_) => const SettingsScreen())),
            ),
          ],
        ),
        body: Padding(
          padding: const EdgeInsets.all(16),
          child: GridView.count(
            crossAxisCount: 2,
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            children: [
              tile(Icons.work_outline, 'ابحث عن عمل', const FindJobScreen()),
              tile(Icons.person_search, 'ابحث عن عامل', const FindWorkerScreen()),
              tile(Icons.monetization_on_outlined, 'اربح معنا', const EarnScreen()),
              tile(Icons.support_agent, 'تواصل معنا', const ContactScreen()),
            ],
          ),
        ),
      ),
    );
  }
}
