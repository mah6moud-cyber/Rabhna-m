import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../config.dart';
import '../services/db.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  Future<void> _open(String url) =>
      launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);

  Future<void> _confirmDelete(BuildContext context) async {
    final pass = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('حذف الحساب نهائياً'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text(
              'سيتم حذف حسابك وسيرتك الذاتية وإعلاناتك ونقاطك. لا يمكن التراجع. '
              'اكتب كلمة المرور للتأكيد.'),
          TextField(
              controller: pass,
              obscureText: true,
              decoration: const InputDecoration(labelText: 'كلمة المرور')),
        ]),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('إلغاء')),
          TextButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('حذف', style: TextStyle(color: Colors.red))),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await Db.deleteAccount(pass.text);
      if (context.mounted) Navigator.of(context).popUntil((r) => r.isFirst);
    } on FirebaseAuthException catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(e.message ?? 'تعذر الحذف')));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('الإعدادات')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Text(Db.me.email ?? ''),
            const SizedBox(height: 12),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Text(
                  'قواعد النقاط والسحب:\n'
                  '• النقاط ليست عملة ولا لها قيمة ثابتة.\n'
                  '• تحصل على ${(kUserShare * 100).round()}% من الإيراد الفعلي المنسوب لنقاطك.\n'
                  '• التحويل يوم $kWithdrawDay من كل شهر بدءاً من 22/11/2026، والمراجعة من 1 إلى 5 أيام عمل.\n'
                  '• الحد الأدنى للسحب $kMinWithdrawPoints نقطة.\n'
                  '• الاحتيال أو النقر الوهمي يؤدي لإلغاء النقاط وإغلاق الحساب.',
                ),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.privacy_tip_outlined),
              title: const Text('سياسة الخصوصية'),
              onTap: () => _open(kPrivacyUrl),
            ),
            ListTile(
              leading: const Icon(Icons.gavel),
              title: const Text('شروط الاستخدام'),
              onTap: () => _open(kTermsUrl),
            ),
            ListTile(
              leading: const Icon(Icons.delete_forever, color: Colors.red),
              title: const Text('حذف الحساب',
                  style: TextStyle(color: Colors.red)),
              onTap: () => _confirmDelete(context),
            ),
            ListTile(
              leading: const Icon(Icons.logout),
              title: const Text('تسجيل الخروج'),
              onTap: () {
                FirebaseAuth.instance.signOut();
                Navigator.of(context).popUntil((r) => r.isFirst);
              },
            ),
          ],
        ),
      ),
    );
  }
}
