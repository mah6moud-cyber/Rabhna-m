import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../config.dart';
import '../../services/db.dart';

/// شاشة منصات الإعلانات (type = 'ads') أو منصات الألعاب (type = 'games').
/// - الإعلانات: AdMob إعلان مكافأة مدمج + أي منصات تضيفها من لوحة التحكم (روابط).
/// - الألعاب: منصات تضيفها من لوحة التحكم (روابط).
class PlatformsScreen extends StatefulWidget {
  final String type;
  const PlatformsScreen({super.key, required this.type});
  @override
  State<PlatformsScreen> createState() => _PlatformsScreenState();
}

class _PlatformsScreenState extends State<PlatformsScreen> {
  RewardedAd? _ad;
  bool _loading = false;

  bool get _isAds => widget.type == 'ads';

  @override
  void initState() {
    super.initState();
    if (_isAds) _loadAd();
  }

  void _loadAd() {
    setState(() => _loading = true);
    RewardedAd.load(
      // قبل النشر: استبدل بمعرّف وحدة الإعلان الحقيقية من AdMob
      adUnitId: kTestRewardedAdUnit,
      request: const AdRequest(),
      rewardedAdLoadCallback: RewardedAdLoadCallback(
        onAdLoaded: (ad) => setState(() {
          _ad = ad;
          _loading = false;
        }),
        onAdFailedToLoad: (_) => setState(() => _loading = false),
      ),
    );
  }

  void _showAd() {
    final ad = _ad;
    if (ad == null) return;
    ad.fullScreenContentCallback = FullScreenContentCallback(
      onAdDismissedFullScreenContent: (a) {
        a.dispose();
        _ad = null;
        _loadAd();
      },
    );
    // التحقق من المكافأة على السيرفر (SSV): AdMob يرسل المستخدم إلى Cloud Function
    ad.setServerSideOptions(ServerSideVerificationOptions(userId: Db.me.uid));
    ad.show(onUserEarnedReward: (_, __) async {
      if (kTestMode) await Db.addPoints(kPointsPerRewardedAd);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text(kTestMode
                ? 'تمت إضافة $kPointsPerRewardedAd نقطة'
                : 'شكراً! تُضاف النقاط بعد التحقق من المشاهدة')));
      }
    });
  }

  Future<void> _openPlatform(String url) async {
    final uri = Uri.parse(url);
    await launchUrl(uri, mode: LaunchMode.externalApplication);
    // ملاحظة: منح النقاط على ألعاب المنصات الخارجية لازم يتم عن طريق
    // إشعار الخادم (postback) من المنصة، مش من التطبيق. راجع README.
  }

  @override
  void dispose() {
    _ad?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
            title: Text(_isAds ? 'اربح من مشاهدة الإعلانات' : 'اربح من لعب الألعاب')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            if (_isAds)
              Card(
                child: ListTile(
                  leading: const Icon(Icons.play_circle_fill, size: 36),
                  title: const Text('شاهد إعلان فيديو (AdMob)'),
                  subtitle: Text('+$kPointsPerRewardedAd نقطة'),
                  trailing: _loading
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(strokeWidth: 2))
                      : FilledButton(
                          onPressed: _ad == null ? _loadAd : _showAd,
                          child: Text(_ad == null ? 'تحميل' : 'شاهد'),
                        ),
                ),
              ),
            const SizedBox(height: 8),
            Text(_isAds ? 'منصات إعلانات أخرى' : 'منصات الألعاب',
                style: const TextStyle(fontWeight: FontWeight.bold)),
            StreamBuilder(
              stream: Db.platforms(widget.type),
              builder: (context, snap) {
                if (!snap.hasData) return const SizedBox();
                final docs = snap.data!.docs;
                if (docs.isEmpty) {
                  return const Padding(
                    padding: EdgeInsets.all(16),
                    child: Text('لا توجد منصات مضافة حالياً'),
                  );
                }
                return Column(
                  children: [
                    for (final d in docs)
                      Card(
                        child: ListTile(
                          leading: Icon(_isAds ? Icons.ads_click : Icons.videogame_asset),
                          title: Text(d.data()['name'] ?? ''),
                          trailing: const Icon(Icons.open_in_new),
                          onTap: () => _openPlatform(d.data()['url'] ?? ''),
                        ),
                      ),
                  ],
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
