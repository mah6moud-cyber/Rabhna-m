import 'package:flutter/material.dart';

import '../../config.dart';
import '../../services/db.dart';
import 'platforms_screen.dart';
import 'withdraw_screen.dart';

class EarnScreen extends StatelessWidget {
  const EarnScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('اربح معنا')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            StreamBuilder(
              stream: Db.myUser(),
              builder: (context, snap) {
                final points = (snap.data?.data()?['points'] ?? 0) as int;
                return Card(
                  color: Theme.of(context).colorScheme.primaryContainer,
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      children: [
                        const Text('رصيدك'),
                        Text('$points نقطة',
                            style: const TextStyle(
                                fontSize: 32, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 8),
                        Text(
                          'يتم تحويل النقاط إلى فلوس يوم 22 من كل شهر، وقد يتم قبول طلب السحب '
                          'من يوم إلى 5 أيام عمل.\nأول عملية سحب تكون من '
                          '${kFirstWithdrawDate.day}/${kFirstWithdrawDate.month}/${kFirstWithdrawDate.year}، '
                          'بشرط مشاهدة الإعلانات ولعب الألعاب يومياً. '
                          'النقاط ليست عملة، وقيمتها تعتمد على الإيراد الفعلي، ونصيبك ${(kUserShare * 100).round()}% منه.',
                          textAlign: TextAlign.center,
                          style: const TextStyle(fontSize: 13),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
            const SizedBox(height: 12),
            _btn(context, Icons.smart_display, 'اربح من مشاهدة الإعلانات',
                const PlatformsScreen(type: 'ads')),
            _btn(context, Icons.sports_esports, 'اربح من لعب الألعاب',
                const PlatformsScreen(type: 'games')),
            _btn(context, Icons.account_balance_wallet, 'طلب سحب',
                const WithdrawScreen()),
          ],
        ),
      ),
    );
  }

  Widget _btn(BuildContext c, IconData i, String t, Widget page) => Card(
        child: ListTile(
          leading: Icon(i, size: 32),
          title: Text(t, style: const TextStyle(fontSize: 17)),
          trailing: const Icon(Icons.chevron_left),
          onTap: () =>
              Navigator.push(c, MaterialPageRoute(builder: (_) => page)),
        ),
      );
}
