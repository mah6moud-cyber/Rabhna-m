import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../config.dart';
import '../../services/db.dart';

class WithdrawScreen extends StatefulWidget {
  const WithdrawScreen({super.key});
  @override
  State<WithdrawScreen> createState() => _WithdrawScreenState();
}

class _WithdrawScreenState extends State<WithdrawScreen> {
  final _points = TextEditingController();
  final _phone = TextEditingController();
  String _method = kWithdrawMethods.first;
  bool _busy = false;

  Future<void> _submit() async {
    final msg = ScaffoldMessenger.of(context);
    if (!isWithdrawOpen()) {
      msg.showSnackBar(const SnackBar(
          content: Text('السحب متاح يوم 22 من كل شهر، بدءاً من 22/11/2026')));
      return;
    }
    final p = int.tryParse(_points.text.trim()) ?? 0;
    final phone = _phone.text.trim();
    if (p < kMinWithdrawPoints) {
      msg.showSnackBar(SnackBar(
          content: Text('الحد الأدنى للسحب $kMinWithdrawPoints نقطة')));
      return;
    }
    if (!RegExp(r'^01[0125][0-9]{8}$').hasMatch(phone)) {
      msg.showSnackBar(const SnackBar(content: Text('رقم المحفظة غير صحيح')));
      return;
    }
    setState(() => _busy = true);
    try {
      await Db.requestWithdraw(points: p, method: _method, phone: phone);
      msg.showSnackBar(const SnackBar(content: Text('تم إرسال طلب السحب')));
      _points.clear();
    } catch (e) {
      msg.showSnackBar(SnackBar(content: Text('$e')));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  String _statusAr(String s) =>
      {'pending': 'قيد المراجعة', 'paid': 'تم التحويل', 'rejected': 'مرفوض'}[s] ?? s;

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('طلب سحب')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            TextField(
              controller: _points,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                  labelText: 'عدد النقاط المراد سحبها',
                  border: OutlineInputBorder()),
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              value: _method,
              decoration: const InputDecoration(
                  labelText: 'طريقة السحب', border: OutlineInputBorder()),
              items: [
                for (final m in kWithdrawMethods)
                  DropdownMenuItem(value: m, child: Text(m))
              ],
              onChanged: (v) => setState(() => _method = v!),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _phone,
              keyboardType: TextInputType.phone,
              decoration: const InputDecoration(
                  labelText: 'رقم المحفظة', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 16),
            FilledButton(
                onPressed: _busy ? null : _submit, child: const Text('إرسال الطلب')),
            const SizedBox(height: 24),
            const Text('طلباتي السابقة',
                style: TextStyle(fontWeight: FontWeight.bold)),
            StreamBuilder(
              stream: Db.myWithdrawals(),
              builder: (context, snap) {
                if (!snap.hasData) return const SizedBox();
                return Column(
                  children: [
                    for (final d in snap.data!.docs)
                      ListTile(
                        title: Text('${d['points']} نقطة - ${d['method']}'),
                        subtitle: Text(d['createdAt'] == null
                            ? ''
                            : DateFormat('yyyy/MM/dd')
                                .format((d['createdAt'] as dynamic).toDate())),
                        trailing: Text(_statusAr(d['status'])),
                      ),
                  ],
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
