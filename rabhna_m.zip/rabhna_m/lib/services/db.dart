import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../config.dart';

/// طبقة الوصول لقاعدة البيانات (Firestore)
///
/// المجموعات:
///  users/{uid}            : name, email, points, createdAt
///  resumes/{uid}          : السيرة الذاتية (واحدة لكل مستخدم) - تظهر في "ابحث عن عامل"
///  jobs/{autoId}          : تفاصيل العمل - تظهر في "ابحث عن عمل"
///  platforms/{autoId}     : منصات الإعلانات/الألعاب (type: ads | games)
///  withdrawals/{autoId}   : طلبات السحب
///  messages/{autoId}      : رسائل "تواصل معنا"
///  settings/config        : revenuePerPoint (الإيراد الحقيقي لكل نقطة بالجنيه)
class Db {
  static final _fs = FirebaseFirestore.instance;
  static User get me => FirebaseAuth.instance.currentUser!;
  static bool get isAdmin => me.email == kAdminEmail;

  static Future<void> createUserDoc(User u) => _fs.collection('users').doc(u.uid).set({
        'email': u.email,
        'points': 0,
        'createdAt': FieldValue.serverTimestamp(),
      });

  static Stream<DocumentSnapshot<Map<String, dynamic>>> myUser() =>
      _fs.collection('users').doc(me.uid).snapshots();

  // ---- السيرة الذاتية / الوظائف ----
  static Future<void> saveResume(Map<String, dynamic> data) =>
      _fs.collection('resumes').doc(me.uid).set({
        ...data,
        'ownerUid': me.uid,
        'updatedAt': FieldValue.serverTimestamp(),
      });

  static Stream<DocumentSnapshot<Map<String, dynamic>>> myResume() =>
      _fs.collection('resumes').doc(me.uid).snapshots();

  static Stream<QuerySnapshot<Map<String, dynamic>>> allResumes() => _fs
      .collection('resumes')
      .orderBy('updatedAt', descending: true)
      .limit(100)
      .snapshots();

  static Future<void> addJob(Map<String, dynamic> data) =>
      _fs.collection('jobs').add({
        ...data,
        'ownerUid': me.uid,
        'createdAt': FieldValue.serverTimestamp(),
      });

  static Stream<QuerySnapshot<Map<String, dynamic>>> allJobs() => _fs
      .collection('jobs')
      .orderBy('createdAt', descending: true)
      .limit(100)
      .snapshots();

  static Stream<QuerySnapshot<Map<String, dynamic>>> myJobs() => _fs
      .collection('jobs')
      .where('ownerUid', isEqualTo: me.uid)
      .snapshots();

  static Future<void> deleteJob(String id) => _fs.collection('jobs').doc(id).delete();

  // ---- المنصات ----
  static Stream<QuerySnapshot<Map<String, dynamic>>> platforms(String type) => _fs
      .collection('platforms')
      .where('type', isEqualTo: type)
      .where('active', isEqualTo: true)
      .snapshots();

  static Future<void> addPlatform(String type, String name, String url) =>
      _fs.collection('platforms').add({
        'type': type,
        'name': name,
        'url': url,
        'active': true,
      });

  // ---- النقاط (تجريبي: من جهة التطبيق) ----
  static Future<void> addPoints(int n) => _fs
      .collection('users')
      .doc(me.uid)
      .update({'points': FieldValue.increment(n)});

  // ---- السحب ----
  static Future<void> requestWithdraw({
    required int points,
    required String method,
    required String phone,
  }) async {
    final userRef = _fs.collection('users').doc(me.uid);
    await _fs.runTransaction((tx) async {
      final snap = await tx.get(userRef);
      final current = (snap.data()?['points'] ?? 0) as int;
      if (points > current) throw 'رصيدك من النقاط غير كافٍ';
      tx.update(userRef, {'points': current - points});
      tx.set(_fs.collection('withdrawals').doc(), {
        'uid': me.uid,
        'email': me.email,
        'points': points,
        'method': method,
        'phone': phone,
        'status': 'pending',
        'createdAt': FieldValue.serverTimestamp(),
      });
    });
  }

  static Stream<QuerySnapshot<Map<String, dynamic>>> myWithdrawals() => _fs
      .collection('withdrawals')
      .where('uid', isEqualTo: me.uid)
      .snapshots();

  // ---- تواصل معنا ----
  static Future<void> sendMessage(String text) =>
      _fs.collection('messages').add({
        'uid': me.uid,
        'email': me.email,
        'text': text,
        'createdAt': FieldValue.serverTimestamp(),
      });

  // ---- المشرف ----
  static Stream<QuerySnapshot<Map<String, dynamic>>> adminUsers() =>
      _fs.collection('users').orderBy('points', descending: true).snapshots();

  static Stream<QuerySnapshot<Map<String, dynamic>>> adminWithdrawals() => _fs
      .collection('withdrawals')
      .orderBy('createdAt', descending: true)
      .snapshots();

  static Stream<QuerySnapshot<Map<String, dynamic>>> adminMessages() => _fs
      .collection('messages')
      .orderBy('createdAt', descending: true)
      .snapshots();

  static Future<void> setWithdrawStatus(String id, String status) =>
      _fs.collection('withdrawals').doc(id).update({'status': status});

  static Stream<DocumentSnapshot<Map<String, dynamic>>> config() =>
      _fs.collection('settings').doc('config').snapshots();

  static Future<void> setRevenuePerPoint(double v) => _fs
      .collection('settings')
      .doc('config')
      .set({'revenuePerPoint': v}, SetOptions(merge: true));

  // ---- الإبلاغ عن محتوى ----
  static Future<void> report({
    required String type, // 'job' | 'resume'
    required String targetId,
    required String reason,
  }) =>
      _fs.collection('reports').add({
        'type': type,
        'targetId': targetId,
        'reason': reason,
        'reporterUid': me.uid,
        'status': 'open',
        'createdAt': FieldValue.serverTimestamp(),
      });

  static Stream<QuerySnapshot<Map<String, dynamic>>> adminReports() => _fs
      .collection('reports')
      .orderBy('createdAt', descending: true)
      .snapshots();

  static Future<void> resolveReport(String id, {String? deleteType, String? deleteId}) async {
    if (deleteType == 'job' && deleteId != null) {
      await _fs.collection('jobs').doc(deleteId).delete();
    } else if (deleteType == 'resume' && deleteId != null) {
      await _fs.collection('resumes').doc(deleteId).delete();
    }
    await _fs.collection('reports').doc(id).update({'status': 'resolved'});
  }

  // ---- حذف الحساب وكل بياناته (مطلوب من جوجل بلاي) ----
  // يتطلب إعادة تسجيل الدخول الحديث؛ نمرر كلمة المرور لإعادة التحقق.
  static Future<void> deleteAccount(String password) async {
    final user = me;
    final cred = EmailAuthProvider.credential(email: user.email!, password: password);
    await user.reauthenticateWithCredential(cred);

    final uid = user.uid;
    final batch = _fs.batch();
    final jobs = await _fs.collection('jobs').where('ownerUid', isEqualTo: uid).get();
    for (final d in jobs.docs) {
      batch.delete(d.reference);
    }
    batch.delete(_fs.collection('resumes').doc(uid));
    // سجلات السحب المنفذة تُحفظ للمراجعة القانونية دون بيانات تعريفية إضافية
    final wds = await _fs.collection('withdrawals').where('uid', isEqualTo: uid).get();
    for (final d in wds.docs) {
      batch.update(d.reference, {'email': FieldValue.delete(), 'phone': FieldValue.delete(), 'deletedUser': true});
    }
    batch.delete(_fs.collection('users').doc(uid));
    await batch.commit();
    await user.delete();
  }
}
