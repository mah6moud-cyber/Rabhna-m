// إعدادات ثابتة للتطبيق. غيّر القيم قبل النشر.

/// بريد المشرف (أنت). لازم يطابق البريد في firestore.rules
const String kAdminEmail = 'ADMIN_EMAIL_HERE';

/// نسبة المستخدم من أرباح المنصات (30%) ونسبتك (70%)
const double kUserShare = 0.30;
const double kOwnerShare = 0.70;

/// أول موعد سحب
final DateTime kFirstWithdrawDate = DateTime(2026, 11, 22);

/// يوم السحب الشهري
const int kWithdrawDay = 22;

/// هل السحب متاح الآن؟ من 22/11/2026 فصاعداً، وفي يوم 22 من كل شهر فقط.
/// في وضع التجربة (kTestMode) السحب متاح دائماً لتجربة الشاشات.
bool isWithdrawOpen([DateTime? now]) {
  if (kTestMode) return true;
  final n = now ?? DateTime.now();
  return !n.isBefore(kFirstWithdrawDate) && n.day == kWithdrawDay;
}

/// نقاط المكافأة عن مشاهدة إعلان واحد (تجريبي)
const int kPointsPerRewardedAd = 10;

/// الحد الأدنى للسحب بالنقاط (عدّله لاحقاً من لوحة التحكم)
const int kMinWithdrawPoints = 1000;

/// وضع التجربة: يستخدم معرّفات إعلانات اختبار جوجل ويسمح بمنح نقاط من جهة التطبيق.
/// قبل النشر: اجعله false وانقل منح النقاط إلى Cloud Functions + AdMob SSV.
const bool kTestMode = true;

/// معرّف إعلان مكافأة تجريبي رسمي من جوجل (Android)
const String kTestRewardedAdUnit = 'ca-app-pub-3940256099942544/5224354917';

const List<String> kWithdrawMethods = [
  'فودافون كاش',
  'موبينيل كاش',
  'اتصالات كاش',
];

// ---- روابط وبيانات قانونية (غيّرها قبل النشر) ----
const String kPrivacyUrl = 'https://YOUR-DOMAIN/privacy_policy.html';
const String kTermsUrl = 'https://YOUR-DOMAIN/terms_of_use.html';
const String kDeleteAccountUrl = 'https://YOUR-DOMAIN/delete_account.html';
const String kSupportEmail = 'SUPPORT_EMAIL_HERE';
