# ربحنا-M

تطبيق Flutter + Firebase: وظائف (ابحث عن عمل / ابحث عن عامل) + ربح نقاط من الإعلانات والألعاب + سحب عبر المحافظ + لوحة تحكم للمشرف.

## 1) تجهيز البيئة
1. ثبّت Flutter و Android Studio: https://docs.flutter.dev/get-started/install
2. في مجلد فاضي شغّل `flutter create rabhna_m --org com.rabhna --platforms android`
3. انسخ فوقه مجلد `lib/` وملفات `pubspec.yaml` و `firestore.rules` من هذا المشروع.
4. شغّل `flutter pub get`

## 2) Firebase
1. أنشئ مشروع على https://console.firebase.google.com
2. أضف تطبيق Android بنفس الـ package name (مثال: `com.rabhna.rabhna_m`) ونزّل `google-services.json` وحطه في `android/app/`
3. فعّل **Authentication > Email/Password** و **Firestore Database**
4. الصق محتوى `firestore.rules` في تبويب Rules وغيّر `ADMIN_EMAIL_HERE` لبريدك، وغيّر نفس القيمة في `lib/config.dart`
5. اعمل أول حساب ببريدك من التطبيق وفعّل البريد (email_verified) عبر Firebase Console حتى تفتح قواعد المشرف.
6. اتبع إعداد Flutter الرسمي لـ Firebase: https://firebase.google.com/docs/flutter/setup

## 3) AdMob (الإعلانات)
- المشروع حالياً بيستخدم **معرّفات اختبار جوجل**. جرّب بيها الأول.
- في `android/app/src/main/AndroidManifest.xml` داخل `<application>` أضف:
  `<meta-data android:name="com.google.android.gms.ads.APPLICATION_ID" android:value="ca-app-pub-3940256099942544~3347511713"/>` (قيمة اختبار، بدّلها بمعرّف تطبيقك الحقيقي من AdMob)
- استخدم **Rewarded Ads فقط**. ممنوع تطلب من المستخدم يضغط على الإعلان.

## 4) أهم ما لازم يتغير قبل النشر
- `kTestMode = false` في `lib/config.dart`.
- **منح النقاط من جهة التطبيق غير آمن** (أي حد يعدّل التطبيق يديّ نفسه نقاط). الحل: AdMob Server-Side Verification + Cloud Functions، وللألعاب postback من المنصة. وبعدها امنع تعديل `points` من العميل في `firestore.rules`.
- حدد "الإيراد الحقيقي لكل نقطة" من لوحة التحكم (تبويب المستخدمين) حسب أرباحك الفعلية، فنصيب المستخدم = 30% منه ونصيبك 70%.
- اكتب سياسة خصوصية (بيانات شخصية + سير ذاتية + إعلانات) وانشرها على رابط عام.

## 5) النشر على جوجل بلاي
1. `flutter build appbundle --release` (بعد إعداد توقيع التطبيق keystore).
2. Play Console > إنشاء تطبيق > ارفع ملف `.aab` في **اختبار مغلق (Closed testing)**.
3. الحساب الشخصي الجديد يحتاج 12 مختبر على الأقل لمدة 14 يوم متواصلة قبل طلب الإنتاج.
4. أكمل: سياسة الخصوصية، Data safety، تصنيف المحتوى، إعلان استخدام الإعلانات، ووصف واضح لنظام النقاط وشروط السحب.
5. اطلب الوصول للإنتاج بعد انتهاء فترة الاختبار.


## 6) الملفات القانونية والإنتاج (أُضيفت)
- `legal/` : privacy_policy.html و terms_of_use.html و delete_account.html. استبدل `[ ]` ثم انشرها على رابط عام، وحدّث الروابط في `lib/config.dart`.
- `firestore.rules.production` : قواعد الإنتاج (العميل لا يزيد النقاط). انشرها بدل `firestore.rules` مع `kTestMode = false`.
- `functions/` : Cloud Functions لمنح النقاط (`postback` لمنصات الألعاب، `admobSsv` لـ AdMob). دالة `verifyAdMobSignature` لازم تكتمل حسب وثائق AdMob قبل التفعيل.
- داخل التطبيق: الإعدادات (الشروط والخصوصية وحذف الحساب)، زر إبلاغ على الوظائف والسير، تبويب البلاغات للمشرف، وموافقة على الشروط عند التسجيل.
