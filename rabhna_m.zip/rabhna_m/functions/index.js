// Cloud Functions لمنح النقاط بعد التحقق (الإنتاج). انشرها: firebase deploy --only functions
const { onRequest } = require("firebase-functions/v2/https");
const { defineSecret } = require("firebase-functions/params");
const admin = require("firebase-admin");
const crypto = require("crypto");

admin.initializeApp();
const db = admin.firestore();

const PLATFORM_SECRET = defineSecret("PLATFORM_SECRET");
const DAILY_CAP = 500; // حد يومي للنقاط لكل مستخدم لمنع الاحتيال (عدّله)

async function grant(uid, points, txid, source) {
  const txRef = db.collection("postbacks").doc(String(txid));
  const userRef = db.collection("users").doc(uid);
  const day = new Date().toISOString().slice(0, 10);
  const capRef = db.collection("dailyCaps").doc(`${uid}_${day}`);
  return db.runTransaction(async (t) => {
    if ((await t.get(txRef)).exists) return "duplicate"; // منع تكرار نفس العملية
    const user = await t.get(userRef);
    if (!user.exists) return "no_user";
    const used = (await t.get(capRef)).data()?.points || 0;
    const add = Math.max(0, Math.min(points, DAILY_CAP - used));
    t.set(txRef, { uid, points: add, source, at: Date.now() });
    t.set(capRef, { points: used + add }, { merge: true });
    if (add > 0) t.update(userRef, { points: admin.firestore.FieldValue.increment(add) });
    return "ok";
  });
}

// 1) منصات الألعاب والعروض: Postback عام. عدّل طريقة التوقيع حسب وثائق كل منصة.
exports.postback = onRequest({ secrets: [PLATFORM_SECRET] }, async (req, res) => {
  const { uid, points, txid, sig } = req.query;
  if (!uid || !points || !txid || !sig) return res.status(400).send("missing");
  const expected = crypto.createHmac("sha256", PLATFORM_SECRET.value())
    .update(`${uid}|${points}|${txid}`).digest("hex");
  const ok = sig.length === expected.length &&
    crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected));
  if (!ok) return res.status(403).send("bad signature");
  const n = Number(points);
  if (!Number.isFinite(n) || n <= 0 || n > 200) return res.status(400).send("bad points");
  res.send(await grant(String(uid), n, `pb_${txid}`, "postback"));
});

// 2) AdMob SSV: AdMob يستدعي هذا الرابط بعد إكمال إعلان المكافأة.
// الرابط يجب أن يتحقق من توقيع جوجل (ECDSA) باستخدام مفاتيح AdMob العامة قبل منح النقاط.
// خطوات التحقق في وثائق AdMob: "Validate server-side verification (SSV) callbacks".
// أكمل verifyAdMobSignature(req) قبل التفعيل. بدونه لا تفعّل هذا المسار.
async function verifyAdMobSignature(/* req */) {
  throw new Error("verifyAdMobSignature غير مكتمل: نفّذه حسب وثائق AdMob قبل الاستخدام");
}
exports.admobSsv = onRequest(async (req, res) => {
  try {
    await verifyAdMobSignature(req);
  } catch (e) {
    return res.status(403).send("signature not verified");
  }
  const { user_id, transaction_id, reward_amount } = req.query;
  const n = Math.min(Number(reward_amount) || 10, 50);
  res.send(await grant(String(user_id), n, `admob_${transaction_id}`, "admob"));
});
